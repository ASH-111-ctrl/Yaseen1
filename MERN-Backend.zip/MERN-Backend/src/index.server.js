const express = require("express");
const env = require("dotenv");
const app = express();
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const userRoutes = require("./routes/user");

env.config();

mongoose
.connect(
    `mongodb+srv://${process.env.MONGO_DB_USER}:${process.env.MONGO_DB_PASSWORD}@cluster0.ihh5s.mongodb.net/${process.env.MONGO_DB_DATABASE}?retryWrites=true&w=majority`
    )
  .then(() => {
    console.log("Database is Connected");
  });

app.use(bodyParser());

app.use('./api',userRoutes)

app.listen(process.env.PORT, () => {
  console.log(`Server is running on Port Number = ${process.env.PORT}`);
});
